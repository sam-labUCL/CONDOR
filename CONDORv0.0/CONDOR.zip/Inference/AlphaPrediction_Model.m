function [Alpha_guess_models] = AlphaPrediction_Model(MomentaIn,Class,Dataset)

dimension = str2double(Dataset.dimension(1));

MomentaIn(end+1,:) = Class; % Model classification added as input

Alpha_guess_models = zeros(1,length(Dataset.size)); % Initialization of array for Alpha guess 

%% Predict Alpha value according to model classification

cd('Model_Method')

cd(['Networks_' num2str(dimension) 'D'])

for mdl = 1:5

    idx1 = find(MomentaIn(end,:) == mdl);  % Trajectories belongs to model mdl

    n_traj = length(idx1);
    x = MomentaIn(1:end-1,idx1);
    x(isnan(x)) = 0; 
    
    load(['Network_SCG' num2str(dimension) 'D_Model' num2str(mdl)])
    
    % Test the Network
    y_alpha = netAlpha(x);
   
    if mdl == 1 || mdl == 2
        AlphaG = [0.2 0.4 0.6 0.8 1]-0.075;
    end

    if mdl == 3 || mdl == 5 
        AlphaG = [1 2]-0.475;
    end

    if mdl == 4
        AlphaG = [1 1.2 1.4 1.6 1.8]+0.075;
    end

    Alpha_guess = AlphaG(vec2ind(y_alpha));
    % MAE_tmp = mean(abs(Alpha_guess-Alpha(idx1)))
    Alpha_guess_models(idx1) = Alpha_guess; 
    
end

%% Refine Alpha estimation for models 3 and 5

mdl1 = [3 5]; 

for m = 1:2
    
    for mm = 1:2

        idx1 = find(MomentaIn(end,:) == mdl1(m)); 

        if mm == 1
            idx2 = find(Alpha_guess_models(idx1) <= 1);
            AlphaG = [0.2 0.4 0.6 0.8 1]-0.075;
        end

        if mm == 2
            idx2 = find(Alpha_guess_models(idx1) > 1);
            AlphaG = [1 1.2 1.4 1.6 1.8]+0.075;
        end

        load(['Network_SCG' num2str(dimension) 'D_Model' num2str(mdl1(m)) '_' num2str(mm)])

        Alpha_tmp = Alpha_guess_models(idx1(idx2));
       
        n_traj = length(idx2);
        x = MomentaIn(1:end-1,idx1(idx2));
        x(isnan(x)) = 0; 
        
        y_alpha = netAlpha(x);
   
        Alpha_guess = AlphaG(vec2ind(y_alpha));
        %MAE_tmp = mean(abs(Alpha_guess-Alpha(idx1(idx2))))
        Alpha_guess_models(idx1(idx2)) = Alpha_guess;   
        
    end

end

% MAE = mean(abs(Alpha_guess_models-Alpha)) % Comment if Alpha reference values not provided

cd ..

cd ..