clearvars; clc; close all

%% Load Alpha values reference if provided
filename = 'AndiDataChal2DExp'; % Load dataset 
load(filename)

filename_save = ['Prediction' filename(13:end)];

Alpha_subnets = AlphaPrediction_Subnetworks(MomentaInputs,Class,Dataset);

Alpha_models = AlphaPrediction_Model(MomentaInputs,Class,Dataset);

% Prediction of Alpha as mean of Alpha guess values from ModelsMethod and SubNetworksMethod

Alpha_guess = mean([Alpha_subnets; Alpha_models]);

clearvars -except Alpha_guess filename_save

save(filename_save)