clearvars; clc; close all

%% Load Alpha reference values
filename = 'AndiDataTest1D'; 
load(filename)

clearvars -except Alpha

%% Divide Alpha values in 4 category for network training 
idxA = [];
idxB = [];
idxC = [];
idxD = [];

for nn = 1:length(Alpha)
    
    if (Alpha(nn) >= 0.05 && Alpha(nn) <= 0.50)
        idxA = [idxA nn];
    end
    
    if (Alpha(nn) > 0.50 && Alpha(nn) <= 1.00)
        idxB = [idxB nn];
    end
    
    if (Alpha(nn) > 1.00 && Alpha(nn) <= 1.50)
        idxC = [idxC nn];
    end
    
    if (Alpha(nn) > 1.50 && Alpha(nn) <= 2.00)
        idxD = [idxD nn];
    end
    
end

clearvars -except Alpha idxA idxB idxC idxD
