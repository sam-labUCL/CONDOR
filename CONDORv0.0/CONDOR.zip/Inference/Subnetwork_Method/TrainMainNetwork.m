% Solve a Pattern Recognition Problem with a Neural Network
%
% This script assumes these variables are defined:
%
%  MomentaInputs - input data.
%  MomentaTargets - target data.

clearvars -except idxA idxB idxC idxD; clc; close all

%% Load Analysed Dataset

filename = 'AndiDataTest1D'; % Load Alpha reference values, trajectories and inputs for the network
load(filename)

dimension = str2double(Dataset.dimension(1));

MomentaInputs(end+1,:) = Class; % Model classification added as input

filename_save = ['Network_SCG' num2str(dimension) 'D']; % Filename to save the network after training 

%% Define targets data for the network

n_targets = 4; % Number of targets
n_traj = length(traj); % Number of analyzed trajectories

MomentaTargets = zeros(n_targets, n_traj);

% For loop to divide the alpha values in 4 different categories: each category is a target for the network
for nn = 1:n_traj
    
    if (Alpha(nn) >= 0.05 && Alpha(nn) <= 0.50) %Category A
        MomentaTargets(1,nn) = 1;
    end
    
    if (Alpha(nn) > 0.50 && Alpha(nn) <= 1.00) %Category B
        MomentaTargets(2,nn) = 1;
    end
    
    if (Alpha(nn) > 1.00 && Alpha(nn) <= 1.50) %Category C
        MomentaTargets(3,nn) = 1;
    end
    
    if (Alpha(nn) > 1.50 && Alpha(nn) <= 2.00) %Category D
        MomentaTargets(4,nn) = 1;
    end
    
end

%% Prepare inputs & targets

x = MomentaInputs;
x(isnan(x)) = 0; % To avoid numerical classification problems
t = MomentaTargets;

%% Choose a Training Function
trainFcn = 'trainscg';

%% Create a Pattern Recognition Network
hiddenLayerSize = 20;
netAlpha = patternnet([hiddenLayerSize hiddenLayerSize], trainFcn);

%% Setup Division of Data for Training, Validation, Testing
netAlpha.divideParam.trainRatio = 70/100;
netAlpha.divideParam.valRatio =  15/100;
netAlpha.divideParam.testRatio = 15/100;

if strcmp(trainFcn, 'trainscg') == 1
    netAlpha.trainParam.max_fail = 100;
    netAlpha.trainParam.epochs = 10000;
end

%% Train the Network
[netAlpha,tr] = train(netAlpha,x,t);

%% Test the Network
y = netAlpha(x);
e = gsubtract(t,y);
performance = perform(netAlpha,t,y);
tind = vec2ind(t);
yind = vec2ind(y);
percentErrors = sum(tind ~= yind)/numel(tind);

%% View the Network
view(netAlpha)

%% Confusion matrix plot 
figure()
plotconfusion(t,y)

%% Save the network
clearvars -except netAlpha performance filename_save idxA idxB idxC idxD

save(filename_save)