clearvars; clc; close all

Dataset.filename_ref = 'none';       % File with model references. Use 'none' if not provided
Dataset.filename_traj = 'task1.txt';     % File with trajectories
Dataset.dimension = '3.0';              % Data dimension (1D, 2D or 3D)
Dataset.size = 1e4;  

n_in = (str2double(Dataset.dimension(1))-1)*1e4+1;  % 3e4+1 (1DExp), 3e4+6619 (2DExp)   
n_fin = str2double(Dataset.dimension(1))*1e4;       % 3e4+6618 (1DExp), 3e4+9927 (2DExp)  

filename_save = ['AndiDataChal' Dataset.dimension(1) 'D'];

ref = strcmp(Dataset.filename_ref,'none');

if ref == 0
  
    M = fileread(Dataset.filename_ref);
    k = strfind(M,native2unicode(10));
    
    if strcmp(Dataset.dimension,'1.0')
        l = 0;
    else
        l = k(n_in-1);
    end
    
    Alpha = zeros(1,Dataset.size);
    for nn = n_in:n_fin 
        MM = M(l+1:k(nn));
        kk = strfind(MM,';');
        Alpha(nn-n_in+1) = str2double(MM(kk+1:end));
        l = k(nn);
    end
    
end
    
T =  fileread(Dataset.filename_traj);
t = strfind(T,native2unicode(10));
t = [1 t];

N = 0;
for mm = n_in:n_fin
   tmp = T(t(mm)+3:t(mm+1)-1);
   tmp(end) = ';';
   tt = strfind(tmp,';');
   traj{mm-n_in+1} = [];
   for ll = 1:length(tt)-1
       traj{mm-n_in+1} = [traj{mm-n_in+1} str2double(tmp(tt(ll)+1:tt(ll+1)-1))];
   end
   
   if mod(mm-n_in+1, 1000) == 0
       disp([num2str(100*N/Dataset.size) '% complete: ' num2str(N) ' extracted trajectories out of ' num2str(Dataset.size)])
       N = N + 1000;
   end

end

clearvars -except Dataset Alpha traj filename_save

save(filename_save)