function [Alpha_guess_subnets] = AlphaPrediction_Subnetworks(MomentaIn,Class,Dataset)

dimension = str2double(Dataset.dimension(1));

MomentaIn(end+1,:) = Class; % Model classification added as input

Alpha_guess_subnets = zeros(1,length(Dataset.size)); % Initialization of array for Alpha guess 

%% Main network: divide Alpha values in 4 main categories (A, B, C, D)

cd('Subnetwork_Method')

cd(['Networks_' num2str(dimension) 'D'])

load(['Network_SCG' num2str(dimension) 'D.mat'])
x = MomentaIn;
x(isnan(x)) = 0;
y = netAlpha(x);
yind = vec2ind(y);

idxA = find(yind == 1); % Category A [0.05:0.50]
idxB = find(yind == 2); % Category B [0.55:1.00]
idxC = find(yind == 3); % Category C [1.05:1.50]
idxD = find(yind == 4); % Category D [1.55:2.00]

clearvars -except MomentaIn Alpha Alpha_guess_subnets dimension idxA idxB idxC idxD filename_save

%% Subnetwork A: refine category A using subcategories and assign Alpha guess values as mean value of the corresponding subcategory
load(['SubNetworkA_SCG' num2str(dimension) 'D.mat'])

range1 = [0.05,0.10]; % Alpha range subA1
range2 = [0.15,0.20]; % Alpha range subA2
range3 = [0.25,0.30]; % Alpha range subA3
range4 = [0.35,0.40]; % Alpha range subA4
range5 = [0.45,0.50]; % Alpha range subA5

x = MomentaIn(:,idxA); 
x(isnan(x)) = 0;
y = netAlphasubA(x);
yind = vec2ind(y);

idxSubA1 = find(yind == 1);
idxSubA2 = find(yind == 2);
idxSubA3 = find(yind == 3);
idxSubA4 = find(yind == 4);
idxSubA5 = find(yind == 5);

Alpha_guess_subnets(1,idxA(idxSubA1)) = mean(range1); 
Alpha_guess_subnets(1,idxA(idxSubA2)) = mean(range2); 
Alpha_guess_subnets(1,idxA(idxSubA3)) = mean(range3); 
Alpha_guess_subnets(1,idxA(idxSubA4)) = mean(range4); 
Alpha_guess_subnets(1,idxA(idxSubA5)) = mean(range5); 

clearvars -except MomentaIn Alpha Alpha_guess_subnets dimension idxA idxB idxC idxD filename_save

%% Subnetwork B: refine category B using subcategories and assign Alpha guess values as mean value of the corresponding subcategory
load(['SubNetworkB_SCG' num2str(dimension) 'D.mat'])

range1 = [0.55,0.60]; % Alpha range subB1
range2 = [0.65,0.70]; % Alpha range subB2
range3 = [0.75,0.80]; % Alpha range subB3
range4 = [0.85,0.90]; % Alpha range subB4
range5 = [0.95,1.00]; % Alpha range subB5

x = MomentaIn(:,idxB);
x(isnan(x)) = 0;
y = netAlphasubB(x);
yind = vec2ind(y);

idxSubB1 = find(yind == 1);
idxSubB2 = find(yind == 2);
idxSubB3 = find(yind == 3);
idxSubB4 = find(yind == 4);
idxSubB5 = find(yind == 5);

Alpha_guess_subnets(1,idxB(idxSubB1)) = mean(range1); 
Alpha_guess_subnets(1,idxB(idxSubB2)) = mean(range2); 
Alpha_guess_subnets(1,idxB(idxSubB3)) = mean(range3); 
Alpha_guess_subnets(1,idxB(idxSubB4)) = mean(range4); 
Alpha_guess_subnets(1,idxB(idxSubB5)) = mean(range5); 

clearvars -except MomentaIn Alpha Alpha_guess_subnets dimension idxA idxB idxC idxD filename_save

%% Subnetwork C: refine category C using subcategories and assign Alpha guess values as mean value of the corresponding subcategory
load(['SubNetworkC_SCG' num2str(dimension) 'D.mat'])

range1 = [1.05,1.10]; % Alpha range subC1
range2 = [1.15,1.20]; % Alpha range subC2
range3 = [1.25,1.30]; % Alpha range subC3
range4 = [1.35,1.40]; % Alpha range subC4
range5 = [1.45,1.50]; % Alpha range subC5

x = MomentaIn(:,idxC);
x(isnan(x)) = 0;
y = netAlphasubC(x);
yind = vec2ind(y);

idxSubC1 = find(yind == 1);
idxSubC2 = find(yind == 2);
idxSubC3 = find(yind == 3);
idxSubC4 = find(yind == 4);
idxSubC5 = find(yind == 5);

Alpha_guess_subnets(1,idxC(idxSubC1)) = mean(range1); 
Alpha_guess_subnets(1,idxC(idxSubC2)) = mean(range2); 
Alpha_guess_subnets(1,idxC(idxSubC3)) = mean(range3); 
Alpha_guess_subnets(1,idxC(idxSubC4)) = mean(range4); 
Alpha_guess_subnets(1,idxC(idxSubC5)) = mean(range5); 

clearvars -except MomentaIn Alpha Alpha_guess_subnets dimension idxA idxB idxC idxD filename_save

%% Subnetwork D: refine category D using subcategories and assign Alpha guess values as mean value of the corresponding subcategory
load(['SubNetworkD_SCG' num2str(dimension) 'D.mat'])

range1 = [1.55,1.60]; % Alpha range subD1
range2 = [1.65,1.70]; % Alpha range subD2
range3 = [1.75,1.80]; % Alpha range subD3
range4 = [1.85,1.90]; % Alpha range subD4
range5 = [1.95,2.00]; % Alpha range subD5

x = MomentaIn(:,idxD);
x(isnan(x)) = 0;
y = netAlphasubD(x);
yind = vec2ind(y);

idxSubD1 = find(yind == 1);
idxSubD2 = find(yind == 2);
idxSubD3 = find(yind == 3);
idxSubD4 = find(yind == 4);
idxSubD5 = find(yind == 5);

Alpha_guess_subnets(1,idxD(idxSubD1)) = mean(range1); 
Alpha_guess_subnets(1,idxD(idxSubD2)) = mean(range2); 
Alpha_guess_subnets(1,idxD(idxSubD3)) = mean(range3); 
Alpha_guess_subnets(1,idxD(idxSubD4)) = mean(range4); 
Alpha_guess_subnets(1,idxD(idxSubD5)) = mean(range5); 

clearvars -except MomentaIn Alpha Alpha_guess_subnets dimension idxA idxB idxC idxD filename_save

%% MAE calculation
% MAE = mean(abs(Alpha_guess_subnets-Alpha))

cd ..

cd ..