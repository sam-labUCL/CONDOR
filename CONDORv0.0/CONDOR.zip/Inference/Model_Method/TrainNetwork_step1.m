% Solve a Pattern Recognition Problem with a Neural Network
%
% This script assumes these variables are defined:
%
%   MomentaInputs - input data.
%   MomentaTargets - target data.

clearvars; clc; close all

%% Select model for training
model = 5; % Select model. Values between 1 and 5

if model == 1 || model == 2 || model == 4
    cat_alpha = 5;
else
    cat_alpha = 2;
end

%% Load Analysed data
filename = 'AndiDataTest1D';
load(filename) %Load Alpha values e traj

MomentaInputs(end+1,:) = Class;

dimension = str2double(Dataset.dimension(1));

idx1 = find(MomentaInputs(end,:) == model); %Trajectory model 
n_traj = length(idx1);

Alpha_guess = Alpha(idx1);

filename_save = ['Network_SCG' num2str(dimension) 'D_Model' num2str(model)]; % Filename to save the network after training 

%% Prepare inputs and targets for training

x = MomentaInputs(1:end-1,idx1);
x(isnan(x)) = 0; 
MomentaTargets = zeros(cat_alpha,n_traj); 

for nn = 1:n_traj
        
    if model == 1 || model == 2
        
        if (Alpha_guess(nn) >= 0.05 && Alpha_guess(nn) <= 0.2) 
             MomentaTargets(1,nn) = 1;
        end

        if (Alpha_guess(nn) >= 0.25 && Alpha_guess(nn) <= 0.4) 
             MomentaTargets(2,nn) = 1;
        end

        if (Alpha_guess(nn) >= 0.45 && Alpha_guess(nn) <= 0.6) 
             MomentaTargets(3,nn) = 1;
        end

        if (Alpha_guess(nn) >= 0.65 && Alpha_guess(nn) <= 0.8) 
             MomentaTargets(4,nn) = 1;
        end

        if (Alpha_guess(nn) >= 0.85) 
            MomentaTargets(5,nn) = 1;
        end
        
    end
    
    if model == 3 || model == 5

        if (Alpha_guess(nn) >= 0.05 && Alpha_guess(nn) <= 1) 
             MomentaTargets(1,nn) = 1;
        end

        if (Alpha_guess(nn) >= 1.05 && Alpha_guess(nn) <= 2) 
            MomentaTargets(2,nn) = 1;
        end

     end
    
    if model == 4
      
        if (Alpha_guess(nn) <= 1.15) 
             MomentaTargets(1,nn) = 1;
        end

        if (Alpha_guess(nn) >= 1.2 && Alpha_guess(nn) <= 1.35)
             MomentaTargets(2,nn) = 1;
        end

        if (Alpha_guess(nn) >= 1.4 && Alpha_guess(nn) <= 1.55)
             MomentaTargets(3,nn) = 1;
        end

        if (Alpha_guess(nn) >= 1.6 && Alpha_guess(nn) <= 1.75)
             MomentaTargets(4,nn) = 1;
        end

        if (Alpha_guess(nn) >= 1.8) 
            MomentaTargets(5,nn) = 1;
            
        end

    end
    
    
end

t = MomentaTargets;

%% Choose a Training Function
trainFcn = 'trainscg';  % Scaled conjugate gradient backpropagation.

%% Create a Pattern Recognition Network
hiddenLayerSize = 20;
netAlpha = patternnet([hiddenLayerSize hiddenLayerSize], trainFcn);

% Setup Division of Data for Training, Validation, Testing
netAlpha.divideParam.trainRatio = 70/100;
netAlpha.divideParam.valRatio =  15/100;
netAlpha.divideParam.testRatio = 15/100;

netAlpha.trainParam.max_fail = 100;
netAlpha.trainParam.epochs = 10000;

%% Train the Network
[netAlpha,tr] = train(netAlpha,x,t);

%% Test the Network
y = netAlpha(x);
e = gsubtract(t,y);
performance = perform(netAlpha,t,y);
tind = vec2ind(t);
yind = vec2ind(y);
percentErrors = sum(tind ~= yind)/numel(tind);

%% View the Network
view(netAlpha)

%% Confusion matrix plot
figure, plotconfusion(t,y)

%% Alpha estimation and MAE calculation from training 
if model == 1 || model == 2
    AlphaG = [0.2 0.4 0.6 0.8 1]-0.075;
end

if model == 3 || model == 5 
    AlphaG = [1 2]-0.475;
end

if model == 4
    AlphaG = [1 1.2 1.4 1.6 1.8]+0.075;
end

Alpha_guess = AlphaG(vec2ind(y));

% MAE_tmp = mean(abs(Alpha_guess-Alpha(idx1)))
% alpha_guess(idx1) = Alpha_guess; 
% 
% MAE = mean(abs(alpha_guess(alpha_guess>0)-Alpha(alpha_guess>0)))

clearvars -except netAlpha performance model filename_save

save(filename_save)