clearvars; clc

filename = 'task1.txt';

load('Prediction1D');
d = 1;

y = Alpha_guess;
n = size(y,2);
data1 = [d*ones(1,n); round(y,3)];
clear y

load('Prediction2D'); 
d = 2;

y = Alpha_guess;
n = size(y,2);
data2 = [d*ones(1,n); round(y,3)];
clear y

load('Prediction3D');
d = 3;

y = Alpha_guess;
n = size(y,2);
data3 = [d*ones(1,n); round(y,3)];
clear y

load('Prediction1DExp'); 
d = 1;

y = Alpha_guess;
n = size(y,2);
data1exp = [d*ones(1,n); round(y,3)];
clear y

load('Prediction2DExp'); 
d = 2;

y = Alpha_guess;
n = size(y,2);
data2exp = [d*ones(1,n); round(y,3)];
clear y

data = [data1 data2 data3 data1exp data2exp];

writematrix(data',filename,'Delimiter',';')

type(filename)