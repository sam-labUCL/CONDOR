% Solve a Pattern Recognition Problem with a Neural Network
%
% This script assumes these variables are defined:
%
%   MomentaInputs - input data.
%   MomentaTargets - target data.

clearvars; clc; close all

%% Load Analysed Dataset

filename = 'AndiDataTest3D'; % use a dataset with at least 1e5 viable attm, ctrw trajectories for training
load(filename)

dimension = str2double(Dataset.dimension(1));

clearvars -except MomentaInputs MomentaTargets Model dimension

filename_save = ['NetworkLM' num2str(dimension) 'D_step1']; % change name 

%% Prepare inputs

x = MomentaInputs;
x(isnan(x)) = 0; % to avoid numerical classification problems
t = MomentaTargets;

%% Choose a Training Function: either 'trainscg' or 'trainlm'
trainFcn = 'trainlm';  

%% Create a Pattern Recognition Network
hiddenLayerSize = 20;
net = patternnet([hiddenLayerSize hiddenLayerSize], trainFcn);

%% Setup Division of Data for Training, Validation, Testing
net.divideParam.trainRatio = 70/100;
net.divideParam.valRatio =  15/100;
net.divideParam.testRatio = 15/100;

if strcmp(trainFcn, 'trainscg') == 1
    net.trainParam.max_fail = 100;
    net.trainParam.epochs = 10000;
end

%% Train the Network
[net,tr] = train(net,x,t);

%% Test the Network
y = net(x);
e = gsubtract(t,y);
performance = perform(net,t,y)
tind = vec2ind(t);
yind = vec2ind(y);
percentErrors = sum(tind ~= yind)/numel(tind);

%% View the Network
view(net)

%% Plots
figure, plotconfusion(t,y)

clearvars -except net performance filename_save

save(filename_save)