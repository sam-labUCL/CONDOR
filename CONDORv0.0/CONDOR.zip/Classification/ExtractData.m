clearvars; clc; close all

%% Initial variables

Dataset.filename_ref = 'ref2.txt';              % File with model references. Use 'none' if not provided
Dataset.filename_traj = 'task2.txt';     % File with trajectories
Dataset.dimension = '3.0';                 % Data dimension (1D, 2D or 3D)
Dataset.size = 1e4;                         % Number of trajectories

n_in = (str2double(Dataset.dimension(1))-1)*1e4+1;  % 3e4+1 (1DExp), 3e4+6619 (2DExp)   
n_fin = str2double(Dataset.dimension(1))*1e4;       % 3e4+6618 (1DExp), 3e4+9927 (2DExp)  

filename_save = ['AndiDataChal' Dataset.dimension(1) 'D'];

%% Extract model references

ref = strcmp(Dataset.filename_ref,'none');

if ref == 0

    M = fileread(Dataset.filename_ref);
    k = strfind(M,[Dataset.dimension ';']);

    Model = zeros(1,Dataset.size);
    for nn = n_in:n_fin 
        Model(nn-n_in+1) = str2double(M(k(nn-n_in+1)+(4:6))) + 1; 
    end

end
%% Extract trajectories

T =  fileread(Dataset.filename_traj);
t = strfind(T,native2unicode(10));
t = [1 t];

N = 0;
for mm = n_in:n_fin
   tmp = T(t(mm)+3:t(mm+1)-1);
   tmp(end) = ';';
   tt = strfind(tmp,';');
   traj{mm-n_in+1} = [];
   for ll = 1:length(tt)-1
       traj{mm-n_in+1} = [traj{mm-n_in+1} str2double(tmp(tt(ll)+1:tt(ll+1)-1))];
   end
   
   if mod(mm-n_in+1, 1000) == 0
       N = N + 1000;
       disp([num2str(100*N/Dataset.size) '% complete: ' num2str(N) ' extracted trajectories out of ' num2str(Dataset.size)])
   end
   
end

%% Save workspace

clearvars -except Dataset Model traj filename_save

save(filename_save)