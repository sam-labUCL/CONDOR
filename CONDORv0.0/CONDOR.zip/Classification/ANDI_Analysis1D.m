% clearvars; clc; close all

%% Load dataset for analysis

filename = 'AndiDataChal1D';
load(filename)

n_traj = length(traj);
n_category = 5;
n_inputs = 113;
delta = 3;

%% calculate network inputs

ref = strcmp(Dataset.filename_ref,'none');

if ref == 0
    MomentaTargets = zeros(n_category,n_traj);
end
MomentaInputs = zeros(n_inputs,n_traj);

N = 0;
for nn = 1:n_traj
    
    % Define targets
    if ref == 0
        MomentaTargets(Model(nn),nn) = 1;
    end
    
    % Prepare trajectory: normalise to std & remove mean
    xn = traj{nn}-mean(traj{nn});
    Delta_x = xn(2:end)-xn(1:end-1);
    normalization = std(Delta_x);
    normalization(normalization==0) = 1; 
    Delta_x = Delta_x./normalization;
    xn = [0 cumsum(Delta_x)];
    xn = xn-mean(xn);
    
    % Trajectory duration
    Tmax(nn) = length(xn);
    MomentaInputs(1,nn) = log(Tmax(nn));
    
    % Velocity
    v = xn(2:end)-xn(1:end-1);
    
    % Trajectory stopping time
    TT = sum(v == 0)/Tmax(nn);
    MomentaInputs(2,nn) = TT;

    % ||velocity||: momenta and statistics
    f = abs(v);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end
    MomentaInputs(3:8,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];

    Rv = rms(f);
    MomentaInputs(84,nn) = Rv;
    clear f
    
    % Velocity relative change
    f = v(2:end)./v(1:end-1);
    MDvr = median(f);

    MomentaInputs(9,nn) = MDvr;
    clear f
         
    % Fourier Transform: momenta & statistics
    fv = abs(fftshift(fft(v)));
    
    f = fv(ceil(Tmax(nn)/2):end)/Tmax(nn); 
    Mft = mean(f);
    MDft = median(f);
    SDft = std(f);
    Sft = skewness(f);
    Kft = kurtosis(f);
    Eft = approximateEntropy(f);

    MomentaInputs(10:15,nn) = [Mft; MDft; SDft; Sft; Kft; Eft];
    
    Rv = rms(f);
    MomentaInputs(85,nn) = Rv;
    clear f

    % Normalized PSD statistics

    f = fv(ceil(Tmax(nn)/2):end).^2/Tmax(nn)^2;
    h = ones(size(f));
    h(1:round(Tmax(nn)/4)) = -1;
    f = f.*h;
    Pf = sum(f);

    clear f

    Pt = zeros(ceil(Tmax(nn)/delta)-1,1);
    for m = 1:ceil(Tmax(nn)/delta)-1
        index = (m-1)*delta;
        f = v(index+(1:delta));
        fv_time = abs(fftshift(fft(f))); 
        fv_time = fv_time.^2;
        Pt(m) = sum(fv_time);
    end

    h = ones(size(Pt));
    h(1:round(size(Pt,1)/2)) = -1;
    dPf = sum(Pt.*h);

    f = abs(Pt);
    Mp = mean(f);
    MDp = median(f);
    SDp = std(f);
    Sp = skewness(f);
    Kp = kurtosis(f);
    if Tmax(nn) > 9
        Ep = approximateEntropy(f);
    else
        Ep = 0;
    end     
    Rp = rms(f);

    MomentaInputs(16:24,nn) = [Pf; dPf; Mp; MDp; SDp; Sp; Kp; Ep; Rp];
    clear f
    
    % signal rate of variation
    
    LT = ischange(xn,'variance','T',20);
    LT = sum(LT == 0)/Tmax(nn);

    MomentaInputs(25,nn) = LT;
 
    % MSD statistics
    
    MSD = zeros(floor(Tmax(nn)/2)-1,1);
    for n = 1:floor(Tmax(nn)/2)-1
      MSD(n) = mean((xn(n+1:n:end)-xn(1:n:end-n)).^2); 
    end
    time = (1:floor(Tmax(nn)/2)-1)';

    v2 = (MSD(2:end)-MSD(1:end-1))./time(1:end-1).^2;
    
    f = abs(v2);
    Mv2 = mean(f);
    MDv2 = median(f);
    SDv2 = std(f);
    Sv2 = skewness(f);
    Kv2 = kurtosis(f);
    Ev2 = approximateEntropy(f);
    
    MomentaInputs(26:31,nn) = [Mv2; MDv2; SDv2; Sv2; Kv2; Ev2];
    Rv = rms(f);
    MomentaInputs(86,nn) = Rv;
    clear f
    
    % velocity: momenta and statistics
    f = v;
    Mvv = mean(f);
    MDvv = median(f);
    Svv = skewness(f);
    Kvv = kurtosis(f);
    Evv = approximateEntropy(f);
    MomentaInputs(32:36,nn) = [Mvv; MDvv; Svv; Kvv; Evv];
    Rv = rms(f);
    MomentaInputs(87,nn) = Rv;
    clear f   
   
    % correlation
    rv = xcorr(v)/Tmax(nn);
    MomentaInputs(37,nn) = sum(rv(Tmax(nn)-1+(0:2)));
    
    % wavelet transform
    
    wt = cwt(v);
    
    f = abs(wt(:,1)); 
    Mft = mean(f);
    MDft = median(f);
    SDft = std(f);
    Sft = skewness(f);
    Kft = kurtosis(f);
    Eft = approximateEntropy(f);

    MomentaInputs(102:107,nn) = [Mft; MDft; SDft; Sft; Kft; Eft];
    clear f
    
    f = abs(wt(:,2)); 
    Mft = mean(f);
    MDft = median(f);
    SDft = std(f);
    Sft = skewness(f);
    Kft = kurtosis(f);
    Eft = approximateEntropy(f);

    MomentaInputs(108:113,nn) = [Mft; MDft; SDft; Sft; Kft; Eft];
    clear f
    
    % ||velocity||, sampling every 2: momenta & statistics
    
    v3 = xn(3:end)-xn(1:end-2);
    
    f = abs(v3);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(38:43,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    Rv = rms(f);
    MomentaInputs(88,nn) = Rv;
    clear f
    
    % ||velocity||, sampling every 3: momenta & statistics

    v4 = xn(4:end)-xn(1:end-3);
    
    f = abs(v4);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(44:49,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    Rv = rms(f);
    MomentaInputs(89,nn) = Rv;
    clear f
    
    % ||velocity||, sampling every 4: momenta & statistics

    v5 = xn(5:end)-xn(1:end-4);
    
    f = abs(v5);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(50:55,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    Rv = rms(f);
    MomentaInputs(90,nn) = Rv;
    clear f
    
   % ||velocity||, sampling every 5: momenta & statistics

   v6 = xn(6:end)-xn(1:end-5);
    
    f = abs(v6);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(56:61,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    Rv = rms(f);
    MomentaInputs(91,nn) = Rv;
    clear f
    
    % ||velocity||, sampling every 6: momenta & statistics

    v7 = xn(7:end)-xn(1:end-6);
    
    % displacement statistics
    f = abs(v7);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(62:67,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    Rv = rms(f);
    MomentaInputs(92,nn) = Rv;
    clear f
    
    % ||velocity||, sampling every 7: momenta & statistics

    v8 = xn(8:end)-xn(1:end-7);
    
    f = abs(v8);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(68:73,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    Rv = rms(f);
    MomentaInputs(93,nn) = Rv;
    clear f
    
    % ||velocity||, sampling every 8: momenta & statistics

    v9 = xn(9:end)-xn(1:end-8);
    
    f = abs(v9);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    % Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(74:78,nn) = [Mv; MDv; SDv; Sv; Kv];% Ev];
    Rv = rms(f);
    MomentaInputs(94,nn) = Rv;
    clear f

    % ||velocity||, sampling every 9: momenta & statistics

    v10 = xn(10:end)-xn(1:end-9);
    
    f = abs(v10);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    % Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(79:83,nn) = [Mv; MDv; SDv; Sv; Kv];% Ev];
    Rv = rms(f);
    MomentaInputs(95,nn) = Rv;
    clear f
    
    % various
    
    LT2 = ischange(v,'variance','T',20);
    LT2 = sum(LT2 == 0)/Tmax(nn);

    MomentaInputs(96,nn) = LT2;
    
    LT3 = ischange(v3,'variance','T',20);
    LT3 = sum(LT3 == 0)/Tmax(nn);

    MomentaInputs(97,nn) = LT3;
    
    LT4 = ischange(v4,'variance','T',20);
    LT4 = sum(LT4 == 0)/Tmax(nn);

    MomentaInputs(98,nn) = LT4;

    LT5 = ischange(v5,'variance','T',20);
    LT5 = sum(LT5 == 0)/Tmax(nn);

    MomentaInputs(99,nn) = LT5;
    
    LT6 = ischange(v6,'variance','T',20);
    LT6 = sum(LT6 == 0)/Tmax(nn);

    MomentaInputs(100,nn) = LT6;
    
    LT7 = ischange(v7,'variance','T',20);
    LT7 = sum(LT7 == 0)/Tmax(nn);
    
    MomentaInputs(101,nn) = LT7;
        
    clear f
    
    if mod(nn,1000) == 1
        disp([num2str(100*N/Dataset.size) '% complete: ' num2str(N) ' extracted trajectories out of ' num2str(Dataset.size)])
        N = N + 1000;
    end
    
end

disp([num2str(100) '% complete: ' num2str(N) ' extracted trajectories out of ' num2str(Dataset.size)])

clearvars -except Dataset Model traj filename MomentaInputs MomentaTargets
save(filename)