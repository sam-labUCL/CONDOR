%% Calculate Model Classification redicted Values

MomentaTargets = [];

filename = 'AndiDataChal3D'; % use a dataset with 1e5 trajectories for training
load(filename)

dimension = str2double(Dataset.dimension(1));

clearvars -except Model MomentaInputs MomentaTargets dimension 

filename_save = ['Prediction' num2str(dimension) 'D'];

x = MomentaInputs;
x(isnan(x)) = 0; % to avoid numerical classification problems
load(['NetworkLM' num2str(dimension) 'D_step1.mat'])
y = net(x);
if ~isempty(MomentaTargets)
    t = MomentaTargets;
    figure, plotconfusion(t,y)
end

y1 = zeros(size(y));
y1(y == max(y)) = 1;
y1ind = vec2ind(y1);
x1 = MomentaInputs(:,y1ind==1 | y1ind==3 | y1ind==5);
x1(isnan(x1)) = 0; % to avoid numerical classification problems
load(['NetworkLM' num2str(dimension) 'D_step2.mat'])
y2 = net(x1);
y(1:2:5,y1ind==1 | y1ind==3 | y1ind==5) = y2;
y(2:2:4,y1ind==1 | y1ind==3 | y1ind==5) = 0;
if ~isempty(MomentaTargets)
    figure, plotconfusion(t,y)
end

y1 = zeros(size(y));
y1(y == max(y)) = 1;
y1ind = vec2ind(y1);
x1 = MomentaInputs(:,y1ind==1 | y1ind==2);
x1(isnan(x1)) = 0; % to avoid numerical classification problems
load(['NetworkLM' num2str(dimension) 'D_step3.mat'])
y2 = net(x1);
y(1:2,y1ind==1 | y1ind==2) = y2;
y(3:5,y1ind==1 | y1ind==2) = 0;
if ~isempty(MomentaTargets)
    figure, plotconfusion(t,y)
end

clearvars -except y filename_save

save(filename_save)