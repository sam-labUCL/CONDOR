clearvars; clc; close all

%% Load dataset for analysis

filename = 'AndiDataTest2D';
load(filename)

n_traj = length(traj);
n_category = 5;
n_inputs = 189;
delta = 3;

%% calculate network inputs

ref = strcmp(Dataset.filename_ref,'none');

if ref == 0
    MomentaTargets = zeros(n_category,n_traj);
end
MomentaInputs = zeros(n_inputs,n_traj);

N = 0;
for nn = 1:n_traj
    
    % Define targets
    if ref == 0    
        MomentaTargets(Model(nn),nn) = 1;
    end
    
    % Prepare trajectory: normalise to std & remove mean
    xn = traj{nn}(1:end/2)-mean(traj{nn}(1:end/2));
    Delta_x = xn(2:end)-xn(1:end-1);
    normalization = std(Delta_x);
    normalization(normalization==0) = 1; 
    Delta_x = Delta_x./normalization;
    xn = [0 cumsum(Delta_x)];
    xn = xn-mean(xn);
    
    yn = traj{nn}(end/2+1:end)-mean(traj{nn}(end/2+1:end));    
    Delta_y = yn(2:end)-yn(1:end-1);
    normalization = std(Delta_y);
    normalization(normalization==0) = 1; 
    Delta_y = Delta_y./normalization;
    yn = [0 cumsum(Delta_y)];
    yn = yn-mean(yn);
      
    % Trajectory duration   
    Tmax(nn) = length(xn);
    MomentaInputs(1,nn) = log(Tmax(nn));
    
    % Velocity x
    vx = xn(2:end)-xn(1:end-1);
    
    % Trajectory stopping time in x
    TT = sum(vx == 0)/Tmax(nn);
    MomentaInputs(2,nn) = TT;

    % ||velocity (x)||: momenta and statistics
    f = abs(vx);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(3:8,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    clear f
    
    % Velocity (x) relative change
    f = vx(2:end)./vx(1:end-1);
    MDvr = median(f);

    MomentaInputs(9,nn) = MDvr;
    clear f
         
    % Fourier Transform (x): momenta & statistics
    fv = abs(fftshift(fft(vx)));
    
    f = fv(ceil(Tmax(nn)/2):end)/Tmax(nn); 
    Mft = mean(f);
    MDft = median(f);
    SDft = std(f);
    Sft = skewness(f);
    Kft = kurtosis(f);
    Eft = approximateEntropy(f);

    MomentaInputs(10:15,nn) = [Mft; MDft; SDft; Sft; Kft; Eft];
    clear f
   
    % Normalized PSD (x) statistics

    f = fv(ceil(Tmax(nn)/2):end).^2/Tmax(nn)^2;
    h = ones(size(f));
    h(1:round(Tmax(nn)/4)) = -1;
    f = f.*h;
    Pf = sum(f);

    clear f

    Pt = zeros(ceil(Tmax(nn)/delta)-1,1);
    for m = 1:ceil(Tmax(nn)/delta)-1
        index = (m-1)*delta;
        f = vx(index+(1:delta));
        fv_time = abs(fftshift(fft(f))); 
        fv_time = fv_time.^2;
        Pt(m) = sum(fv_time);
    end

    h = ones(size(Pt));
    h(1:round(size(Pt,1)/2)) = -1;
    dPf = sum(Pt.*h);

    f = abs(Pt);
    Mp = mean(f);
    MDp = median(f);
    SDp = std(f);
    Sp = skewness(f);
    Kp = kurtosis(f);
    if Tmax(nn) > 9
        Ep = approximateEntropy(f);
    else
        Ep = 0;
    end     
    Rp = rms(f);

    MomentaInputs(16:24,nn) = [Pf; dPf; Mp; MDp; SDp; Sp; Kp; Ep; Rp];
    clear f
    
    % signal (x) rate of variation

    LT = ischange(xn,'variance','T',20);
    LT = sum(LT == 0)/Tmax(nn);

    MomentaInputs(25,nn) = LT;
    
    % MSD (x) statistics
    
    MSD = zeros(floor(Tmax(nn)/2)-1,1);
    for n = 1:floor(Tmax(nn)/2)-1
      MSD(n) = mean((xn(n+1:n:end)-xn(1:n:end-n)).^2); 
    end
    time = (1:floor(Tmax(nn)/2)-1)';

    v2 = (MSD(2:end)-MSD(1:end-1))./time(1:end-1).^2;
    
    f = abs(v2);
    Mv2 = mean(f);
    MDv2 = median(f);
    SDv2 = std(f);
    Sv2 = skewness(f);
    Kv2 = kurtosis(f);
    Ev2 = approximateEntropy(f);
    
    MomentaInputs(26:31,nn) = [Mv2; MDv2; SDv2; Sv2; Kv2; Ev2];
    clear f
    
    % velocity (x): momenta and statistics
    f = vx;
    Mvv = mean(f);
    MDvv = median(f);
    Svv = skewness(f);
    Kvv = kurtosis(f);
    Evv = approximateEntropy(f);
    MomentaInputs(32:36,nn) = [Mvv; MDvv; Svv; Kvv; Evv];
    clear f   
   
    % correlation (x)
    
    rv = xcorr(vx)/Tmax(nn);
    MomentaInputs(37,nn) = sum(rv(Tmax(nn)-1+(0:2)));
    
    % wavelet transform (x)
    
    wt = cwt(vx);
    
    f = abs(wt(:,1)); 
    Mft = mean(f);
    MDft = median(f);
    SDft = std(f);
    Sft = skewness(f);
    Kft = kurtosis(f);
    Eft = approximateEntropy(f);

    MomentaInputs(166:171,nn) = [Mft; MDft; SDft; Sft; Kft; Eft];
    clear f
    
    f = abs(wt(:,2)); 
    Mft = mean(f);
    MDft = median(f);
    SDft = std(f);
    Sft = skewness(f);
    Kft = kurtosis(f);
    Eft = approximateEntropy(f);

    MomentaInputs(172:177,nn) = [Mft; MDft; SDft; Sft; Kft; Eft];
    clear f
    
    % ||velocity (x)||, sampling every 2: momenta & statistics
    
    v3 = xn(3:end)-xn(1:end-2);
    
    f = abs(v3);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(38:43,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    clear f

    % ||velocity (x)||, sampling every 3: momenta & statistics
    
    v4 = xn(4:end)-xn(1:end-3);
    
    f = abs(v4);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(44:49,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    clear f
    
    % ||velocity (x)||, sampling every 4: momenta & statistics
  
    v5 = xn(5:end)-xn(1:end-4);

    f = abs(v5);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(50:55,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    clear f
    
    % ||velocity (x)||, sampling every 5: momenta & statistics
    
    v6 = xn(6:end)-xn(1:end-5);
    
    f = abs(v6);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(56:61,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    clear f

    % ||velocity (x)||, sampling every 6: momenta & statistics

    v7 = xn(7:end)-xn(1:end-6);
    
    f = abs(v7);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(62:67,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    clear f
    
    % ||velocity (x)||, sampling every 7: momenta & statistics
    
    v8 = xn(8:end)-xn(1:end-7);
    
    f = abs(v8);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(68:73,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    clear f

    % ||velocity (x)||, sampling every 8: momenta & statistics
    
    v9 = xn(9:end)-xn(1:end-8);
    
    f = abs(v9);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    % Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(74:78,nn) = [Mv; MDv; SDv; Sv; Kv];% Ev];
    clear f

    % ||velocity (x)||, sampling every 9: momenta & statistics

    v10 = xn(10:end)-xn(1:end-9);
    
    f = abs(v10);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    % Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(79:83,nn) = [Mv; MDv; SDv; Sv; Kv];% Ev];
    clear f
    
    % Velocity y
    vy = yn(2:end)-yn(1:end-1);

    % Trajectory stopping time in y
    TT = sum(vy == 0)/Tmax(nn);
    MomentaInputs(84,nn) = TT;

    % ||velocity (y)||: momenta and statistics
    f = abs(vy);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(85:90,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    clear f
    
    % Velocity (y) relative change
    f = vy(2:end)./vy(1:end-1);
    MDvr = median(f);

    MomentaInputs(91,nn) = MDvr;
    clear f
         
    % Fourier Transform (y): momenta & statistics
    fv = abs(fftshift(fft(vy)));
    
    f = fv(ceil(Tmax(nn)/2):end)/Tmax(nn); 
    Mft = mean(f);
    MDft = median(f);
    SDft = std(f);
    Sft = skewness(f);
    Kft = kurtosis(f);
    Eft = approximateEntropy(f);

    MomentaInputs(92:97,nn) = [Mft; MDft; SDft; Sft; Kft; Eft];
    clear f
   
    % Normalized PSD (y) statistics

    f = fv(ceil(Tmax(nn)/2):end).^2/Tmax(nn)^2;
    h = ones(size(f));
    h(1:round(Tmax(nn)/4)) = -1;
    f = f.*h;
    Pf = sum(f);

    clear f

    Pt = zeros(ceil(Tmax(nn)/delta)-1,1);
    for m = 1:ceil(Tmax(nn)/delta)-1
        index = (m-1)*delta;
        f = vy(index+(1:delta));
        fv_time = abs(fftshift(fft(f))); 
        fv_time = fv_time.^2;
        Pt(m) = sum(fv_time);
    end

    h = ones(size(Pt));
    h(1:round(size(Pt,1)/2)) = -1;
    dPf = sum(Pt.*h);

    f = abs(Pt);
    Mp = mean(f);
    MDp = median(f);
    SDp = std(f);
    Sp = skewness(f);
    Kp = kurtosis(f);
    if Tmax(nn) > 9
        Ep = approximateEntropy(f);
    else
        Ep = 0;
    end     
    Rp = rms(f);

    MomentaInputs(98:106,nn) = [Pf; dPf; Mp; MDp; SDp; Sp; Kp; Ep; Rp];
    clear f
 
    % signal rate of variation in y

    LT = ischange(yn,'variance','T',20);
    LT = sum(LT == 0)/Tmax(nn);

    MomentaInputs(107,nn) = LT;
 
    % MSD statistics (y)

    MSD = zeros(floor(Tmax(nn)/2)-1,1);
    for n = 1:floor(Tmax(nn)/2)-1
      MSD(n) = mean((yn(n+1:n:end)-yn(1:n:end-n)).^2); 
    end
    time = (1:floor(Tmax(nn)/2)-1)';

    v2 = (MSD(2:end)-MSD(1:end-1))./time(1:end-1).^2;
    
    f = abs(v2);
    Mv2 = mean(f);
    MDv2 = median(f);
    SDv2 = std(f);
    Sv2 = skewness(f);
    Kv2 = kurtosis(f);
    Ev2 = approximateEntropy(f);
    
    MomentaInputs(108:113,nn) = [Mv2; MDv2; SDv2; Sv2; Kv2; Ev2];
    clear f
    
    % velocity (y): momenta and statistics
    f = vy;
    Mvv = mean(f);
    MDvv = median(f);
    Svv = skewness(f);
    Kvv = kurtosis(f);
    Evv = approximateEntropy(f);
    MomentaInputs(114:118,nn) = [Mvv; MDvv; Svv; Kvv; Evv];
    clear f   
   
    % correlation (y)
    
    rv = xcorr(vy)/Tmax(nn);
    MomentaInputs(119,nn) = sum(rv(Tmax(nn)-1+(0:2)));
    
    % wavelet transform (y)
    
    wt = cwt(vy);
    
    f = abs(wt(:,1)); 
    Mft = mean(f);
    MDft = median(f);
    SDft = std(f);
    Sft = skewness(f);
    Kft = kurtosis(f);
    Eft = approximateEntropy(f);

    MomentaInputs(178:183,nn) = [Mft; MDft; SDft; Sft; Kft; Eft];
    clear f
    
    f = abs(wt(:,2)); 
    Mft = mean(f);
    MDft = median(f);
    SDft = std(f);
    Sft = skewness(f);
    Kft = kurtosis(f);
    Eft = approximateEntropy(f);

    MomentaInputs(184:189,nn) = [Mft; MDft; SDft; Sft; Kft; Eft];
    clear f
    
    % ||velocity (y)||, sampling every 2: momenta & statistics
    
    v3 = yn(3:end)-yn(1:end-2);
    
    f = abs(v3);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(120:125,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    clear f

    % ||velocity (y)||, sampling every 3: momenta & statistics

    v4 = yn(4:end)-yn(1:end-3);
    
    f = abs(v4);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(126:131,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    clear f

    % ||velocity (y)||, sampling every 4: momenta & statistics
   
    v5 = yn(5:end)-yn(1:end-4);
    
    f = abs(v5);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(132:137,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    clear f
    
    % ||velocity (y)||, sampling every 5: momenta & statistics
    
    v6 = yn(6:end)-yn(1:end-5);
    
    f = abs(v6);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(138:143,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    clear f
    
    % ||velocity (y)||, sampling every 6: momenta & statistics
    
    v7 = yn(7:end)-yn(1:end-6);
    
    f = abs(v7);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(144:149,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    clear f

    % ||velocity (y)||, sampling every 7: momenta & statistics
    
    v8 = yn(8:end)-yn(1:end-7);
    
    f = abs(v8);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(150:155,nn) = [Mv; MDv; SDv; Sv; Kv; Ev];
    clear f
    
    % ||velocity (y)||, sampling every 8: momenta & statistics
    
    v9 = yn(9:end)-yn(1:end-8);
    
    f = abs(v9);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    % Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(156:160,nn) = [Mv; MDv; SDv; Sv; Kv];% Ev];
    clear f
    
    % ||velocity (y)||, sampling every 9: momenta & statistics
    
    v10 = yn(10:end)-yn(1:end-9);
    
    f = abs(v10);
    Mv = mean(f);
    MDv = median(f);
    SDv = std(f);
    Sv = skewness(f);
    Kv = kurtosis(f);
    % if Tmax(nn) > 15
    % Ev = approximateEntropy(f);
    % else
    %    Ev = 0;
    % end      
    MomentaInputs(161:165,nn) = [Mv; MDv; SDv; Sv; Kv];% Ev];
    clear f
           
    if mod(nn,1000) == 1
        disp([num2str(100*N/Dataset.size) '% complete: ' num2str(N) ' extracted trajectories out of ' num2str(Dataset.size)])
        N = N + 1000;
    end
    
end

disp([num2str(100) '% complete: ' num2str(N) ' extracted trajectories out of ' num2str(Dataset.size)])

clearvars -except Dataset Model traj filename MomentaInputs MomentaTargets
save(filename)