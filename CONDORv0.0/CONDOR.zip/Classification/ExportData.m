clearvars; clc

filename = 'task2.txt';

r = 1e4;

load('Prediction1D');
d = 1;

n = size(y,2);

y_mod = round(y*r)/r;

data1 = [d*ones(1,n); y_mod];

clear y

load('Prediction2D'); 
d = 2;

n = size(y,2);

y_mod = round(y*r)/r;

data2 = [d*ones(1,n); y_mod];

clear y

load('Prediction3D'); 
d = 3;

n = size(y,2);

y_mod = round(y*r)/r;

data3 = [d*ones(1,n); y_mod];

clear y

load('Prediction1DExp');
d = 1;

n = size(y,2);

y_mod = round(y*r)/r;

data4 = [d*ones(1,n); y_mod];

clear y

load('Prediction2DExp'); 
d = 2;

n = size(y,2);

y_mod = round(y*r)/r;

data5 = [d*ones(1,n); y_mod];

clear y

data = [data1 data2 data3 data4 data5];

writematrix(data',filename,'Delimiter',';')

type(filename)